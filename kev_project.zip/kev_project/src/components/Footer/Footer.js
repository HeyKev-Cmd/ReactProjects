import React from 'react'
import "./Footer.js";
export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer-copyright">
        &copy; 2023 Your Kevin
      </div>
  </footer>
  )
}
