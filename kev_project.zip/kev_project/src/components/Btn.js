import React from 'react'

export default function Btn({visible,setVisibility}) {
    const buttonStyles={
            backgroundColor: '#007bff',
            color: '#fff',
            padding: '10px 20px',
            borderRadius: '5px',
            cursor: 'pointer',
                };
    const show=()=>{
        setVisibility(!visible);
    }
    return (
        <button style={buttonStyles} onClick={show}>
            {visible ? 'Hide' : 'Know more about Kevin'}
        </button>
    )
}
