import React from 'react'
import './Header.css'; // Import the CSS file
export default function Header() {
  return (
    <header className="header">
      <nav className="navbar">
        <div className="logo">
          <a href="/">Kevin </a>
        </div>
        <ul className="nav-list">
          <li className="nav-item">
            <a href="/">Home</a>
          </li>
          <li className="nav-item">
            <a href="/about">About</a>
          </li>
          <li className="nav-item">
            <a href="/portfolio">Portfolio</a>
          </li>
          <li className="nav-item">
            <a href="/contact">Contact</a>
          </li>
        </ul>
      </nav>
    </header>
  )
}
