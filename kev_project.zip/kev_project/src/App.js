import React ,{ useState } from 'react'

import logo from './logo.svg';
import './App.css';
import Header from './components/Header/Header.js';
import Btn from './components/Btn.js';
// import Sidebar from './components/Sidebar';
import Footer from './components/Footer/Footer.js';
import Content from './components/Content/Content.js';

function App() {
  const [visible, setVisibility] = useState(false);

  return (
    <div>
      <center>
        <Header/>
        <Btn visible={visible} setVisibility={setVisibility} />
        { visible && <Content/>}
        <Footer/>
      </center>

    </div>
    
  );
}

export default App;
